package wce.ty.cse.mp2.resourceService;

import org.springframework.data.repository.CrudRepository;

public interface ResourceRepository extends CrudRepository<Resources, String>{

}
