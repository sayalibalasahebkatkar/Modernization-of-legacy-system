package wce.ty.cse.mp2.OpportunityService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpportunityServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpportunityServiceApplication.class, args);
	}

}
