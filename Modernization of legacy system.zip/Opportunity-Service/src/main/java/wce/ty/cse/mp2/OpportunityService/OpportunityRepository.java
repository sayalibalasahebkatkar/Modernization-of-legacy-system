package wce.ty.cse.mp2.OpportunityService;
import org.springframework.data.repository.CrudRepository;

public interface OpportunityRepository extends CrudRepository<Opportunity,String>{

}
