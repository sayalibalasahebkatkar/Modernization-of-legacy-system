package wce.ty.cse.mp2.OpportunityService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpportunityServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
